A (library) that helps save your Keras models and then puts them in an easily interactive customtkinter window, no need for any fancy tensorflow.js for an easily interactive app with your model!
